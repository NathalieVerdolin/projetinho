import styles from './Footer.module.css';

export function Footer() {
  return (
    <footer className={styles.footer}>
      <p>© 2026 MeuPortfólio. Todos os direitos reservados.</p>
    </footer>
  );
}