import { Link } from 'react-router-dom';
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import Container from '../../components/Container';
import styles from './Home.module.css';

export function Home() {
  return (
    <>
      <Header />
      <Container>
        <section className={styles.home}>
          <div className={styles.apresentacao}>
            <h1>Olá, sou o <span className={styles.highlight}>Desenvolvedor</span></h1>
            <p>
              Transformando ideias em aplicações web modernas, responsivas e de alta performance com React.
            </p>
            <Link to="/sobre" className={`${styles.btn} ${styles.btnRed}`}>
              Saiba mais sobre nós!
            </Link>
          </div>
          <div className={styles.heroImage}>
            <img src="/developer.svg" alt="Ilustração de Desenvolvedor" />
          </div>
        </section>
      </Container>
      <Footer />
    </>
  );
}

export default Home;