import { Header } from '../../components/Header';
import { Footer } from '../../components/Footer';
import { Container } from '../../components/Container';

export function Contatos() {
  return (
    <>
      <Header />
      <Container>
        <h1>Contatos</h1>
        <p>Entre em contato conosco através dos canais abaixo.</p>
      </Container>
      <Footer />
    </>
  );
}

export default Contatos;