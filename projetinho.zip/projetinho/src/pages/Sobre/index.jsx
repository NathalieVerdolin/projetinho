import Header from '../../components/Header';
import Footer from '../../components/Footer';
import Container from '../../components/Container';

export function Sobre() {
  return (
    <>
      <Header />
      <Container>
        <h2>Sobre</h2>
        <p>Conheça mais sobre a nossa trajetória e objetivos.</p>
      </Container>
      <Footer />
    </>
  );
}

export default Sobre;