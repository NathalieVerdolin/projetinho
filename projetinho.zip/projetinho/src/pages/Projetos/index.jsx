import { Header } from '../../components/Header';
import { Footer } from '../../components/Footer';
import { Container } from '../../components/Container';

export function Projetos() {
  return (
    <>
      <Header />
      <Container>
        <h1>Projetos</h1>
        <p>Confira os principais projetos desenvolvidos.</p>
      </Container>
      <Footer />
    </>
  );
}

export default Projetos;