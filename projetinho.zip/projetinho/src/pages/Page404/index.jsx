import Header from '../../components/Header';
import Footer from '../../components/Footer';
import Container from '../../components/Container';
import styles from './Page404.module.css';

export function Page404() {
  return (
    <>
      <Header />
      <Container>
        <div className={styles.erro}>
          <h2>Ops! Página não encontrada</h2>
          <h1>404</h1>
          <p>Desculpe, a página que você está procurando não existe.</p>
        </div>
      </Container>
      <Footer />
    </>
  );
}

export default Page404;